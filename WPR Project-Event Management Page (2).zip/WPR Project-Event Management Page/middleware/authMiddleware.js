const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.user) {
    return next(); // allow through
  }
  res.redirect('/auth/login');
};

// Checks if logged-in user is an admin
const isAdmin = (req, res, next) => {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next(); // allow through
  }
  res.status(403).render('error', { message: 'Access denied. Admins only.' });
};

module.exports = { isAuthenticated, isAdmin };