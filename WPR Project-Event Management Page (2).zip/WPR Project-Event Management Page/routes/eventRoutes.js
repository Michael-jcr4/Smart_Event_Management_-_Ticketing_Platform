const express = require('express');
const router = express.Router();
const { isAuthenticated, isAdmin } = require('../middleware/authMiddleware');
const {
  getAllEvents,
  getCreateForm,
  createEvent,
  getEditForm,
  updateEvent,
  deleteEvent
} = require('../controllers/eventController');

// All routes below require login AND admin role
router.get('/', isAuthenticated, isAdmin, getAllEvents);
router.get('/create', isAuthenticated, isAdmin, getCreateForm);
router.post('/create', isAuthenticated, isAdmin, createEvent);
router.get('/:id/edit', isAuthenticated, isAdmin, getEditForm);
router.post('/:id/edit', isAuthenticated, isAdmin, updateEvent);
router.post('/:id/delete', isAuthenticated, isAdmin, deleteEvent);

module.exports = router;
