const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Event title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Description is required']
  },
  category: {
    type: String,
    enum: ['conference', 'workshop', 'festival', 'private'],
    required: true
  },
  date: {
    type: Date,
    required: [true, 'Event date is required']
  },
  location: {
    type: String,
    required: true
  },
  totalCapacity: {
    type: Number,
    required: true,
    min: 1
  },
  bookedCount: {
    type: Number,
    default: 0
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { timestamps: true });

// Virtual field: how many tickets are still available
eventSchema.virtual('availableTickets').get(function () {
  return this.totalCapacity - this.bookedCount;
});

module.exports = mongoose.model('Event', eventSchema);