const Event = require('../models/Event');

// GET /events — show all events (admin dashboard view)
const getAllEvents = async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 }); // sorted by date
    res.render('events/index', { events, user: req.session.user });
  } catch (err) {
    res.status(500).render('error', { message: 'Failed to load events' });
  }
};

// GET /events/create — show create form
const getCreateForm = (req, res) => {
  res.render('events/create', { user: req.session.user });
};

// POST /events/create — handle form submission
const createEvent = async (req, res) => {
  try {
    const { title, description, category, date, location, totalCapacity, price } = req.body;
    await Event.create({
      title,
      description,
      category,
      date,
      location,
      totalCapacity,
      price,
      createdBy: req.session.user._id
    });
    res.redirect('/events');
  } catch (err) {
    res.status(400).render('events/create', {
      error: 'Failed to create event. Check all fields.',
      user: req.session.user
    });
  }
};

// GET /events/:id/edit — show edit form
const getEditForm = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).render('error', { message: 'Event not found' });
    res.render('events/edit', { event, user: req.session.user });
  } catch (err) {
    res.status(500).render('error', { message: 'Error loading event' });
  }
};

// POST /events/:id/edit — handle update
const updateEvent = async (req, res) => {
  try {
    const { title, description, category, date, location, totalCapacity, price } = req.body;
    await Event.findByIdAndUpdate(req.params.id, {
      title, description, category, date, location, totalCapacity, price
    }, { runValidators: true });
    res.redirect('/events');
  } catch (err) {
    res.status(400).render('error', { message: 'Failed to update event' });
  }
};

// POST /events/:id/delete — handle delete
const deleteEvent = async (req, res) => {
  try {
    await Event.findByIdAndDelete(req.params.id);
    res.redirect('/events');
  } catch (err) {
    res.status(500).render('error', { message: 'Failed to delete event' });
  }
};

module.exports = { getAllEvents, getCreateForm, createEvent, getEditForm, updateEvent, deleteEvent };