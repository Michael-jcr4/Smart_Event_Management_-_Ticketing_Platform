const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Event title is required"],
      trim: true
    },

    description: {
      type: String,
      required: [true, "Description is required"],
      trim: true
    },

    category: {
      type: String,
      enum: ["Conference", "Workshop", "Festival", "Private"],
      required: [true, "Category is required"]
    },

    //two date var incase event is over multiple days
    startDate: {
    type: Date,
    required: [true, "Start date is required"]
    },

    endDate: {
    type: Date,
    required: [true, "End date is required"]
    },

    location: {
      type: String,
      required: [true, "Location is required"],
      trim: true
    },

    totalCapacity: {
      type: Number,
      required: [true, "Total capacity is required"],
      min: 1
    },

    bookedCount: {
      type: Number,
      default: 0
    },

    price: {
      type: Number,
      required: [true, "Price is required"],
      min: 0
    },

    image: {
      type: String,
      default: ""
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false
    }
  },
  { 
    timestamps: true 
  }
);

eventSchema.virtual("availableTickets").get(function () {
  return this.totalCapacity - this.bookedCount;
});

eventSchema.pre("save", function (next) 
{
  if (this.endDate < this.startDate) {
    return next(new Error("End date cannot be before start date"));
  }
  next();
});

module.exports = mongoose.model("Event", eventSchema);