const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const path = require("path");

const { setUserLocals } = require("./middleware/authMiddleware");
const enquiryRoutes = require("./routes/enquiryRoutes");
const eventRoutes = require("./routes/eventRoutes");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    secret: "smart-event-secret-key",
    resave: false,
    saveUninitialized: false
  })
);

app.use(setUserLocals);

// Temporary test routes.
// Remove these once your real authentication system is connected.
app.get("/test-login-user", (req, res) => {
  req.session.user = {
    id: "000000000000000000000001",
    name: "Standard User",
    email: "user@example.com",
    role: "user"
  };

  res.redirect("/contact");
});

app.get("/test-login-admin", (req, res) => {
  req.session.user = {
    id: "000000000000000000000002",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin"
  };

  res.redirect("/contact");
});

app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/auth");
  });
});

app.get("/auth", (req, res) => {
  res.send(`
    <h1>Temporary Auth Page</h1>
    <p>This is only included so the contact page can be tested.</p>
    <a href="/test-login-user">Login as Standard User</a><br>
    <a href="/test-login-admin">Login as Admin</a>
  `);
});

app.get("/", (req, res) => {
  res.redirect("/contact");
});

app.get("/dashboard", (req, res) => {
  res.send("<h1>Dashboard Placeholder</h1><a href='/contact'>Go to Contact Page</a>");
});

app.get("/admin/events", (req, res) => {
  res.send("<h1>Admin Events Placeholder</h1><a href='/contact'>Go to Contact Page</a>");
});

app.use(enquiryRoutes);

mongoose
  .connect("mongodb://127.0.0.1:27017/smart_event_platform")
  .then(() => {
    console.log("MongoDB connected successfully");

    app.listen(3000, () => {
      console.log("Server running on http://localhost:3000");
    });
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error);
  });
