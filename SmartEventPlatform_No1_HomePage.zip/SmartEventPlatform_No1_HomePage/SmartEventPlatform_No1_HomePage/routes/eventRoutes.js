const express = require("express");
const router = express.Router();

const eventController = require("../controllers/eventController");

//no auth required because home page accessible to everyone
router.get("/", eventController.getHomePage);

module.exports = router;