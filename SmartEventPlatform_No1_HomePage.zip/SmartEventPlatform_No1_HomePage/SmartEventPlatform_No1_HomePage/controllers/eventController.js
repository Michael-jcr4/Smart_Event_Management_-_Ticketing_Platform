const Event = require("../models/Event");

exports.getHomePage = async (req, res) => {
    try
    {
        const {search, category, date, availability} = req.query;

        //filter by what user chooses
        let filter = {}; 

        //filter by title or description
        if(search)
        {
            filter.$or = //checks title or desc and matches if search appears in either
            [ 
                { title: { $regex: search, $options: "i" } }, //$regex: search retrieve where searched value is found anywhere in result
                { description: { $regex: search, $options: "i" } } //$options: "i" is for case sensitivity
            ]
        }
        
        //filters by category
        if (category) 
        {
            filter.category = category
        }

        //filters by date
        if (date)
        {
            const start = new Date(date);
            start.setHours(0, 0, 0, 0); // set to day start

            const end = new Date(date);
            end.setHours(23, 59, 59, 999) //set to just before midnight
            
            filter.startDate = { $lte: end} //start on or before day picked -- $lte acts as <=
            filter.endDate = {$gte: start} // active on or after day picked -- $gte acts as >=
        }

        if (availability == "available") //checks if its available
        {
            filter.$expr = {$lt: ["$bookedCount" , "$totalCapacity"]} //compares the two fields
        }

        const events = await Event.find(filter).sort({startDate: 1}) //search in asc order of start date

        //renders home page and events
        res.render("home",
            {
                pageTitle: "Home - Upcoming Events",
                events,
                search: search || "",
                selectedCategory: category || "",
                selectedDate: date || "",
                selectedAvailability: availability|| "",
                errorMessage: null
            }
        )
    }
    catch (error)
    {
        console.error("Home page error", error);

        //renders error on home page
        res.render("home", 
            {
                pageTitle: "Home - Upcoming Events",
                events: [], //renders empty because of error
                search: "",
                selectedCategory: "",
                selectedDate: "",
                selectedAvailability: "",
                errorMessage: "Unable to load events. Please try again."
            }
        )
    }
}