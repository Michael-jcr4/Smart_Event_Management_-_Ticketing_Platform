const express = require("express");
const router = express.Router();

const enquiryController = require("../controllers/enquiryController");
const { isAuthenticated, isAdmin } = require("../middleware/authMiddleware");

router.get(
  "/contact",
  isAuthenticated,
  enquiryController.getContactPage
);

router.post(
  "/contact",
  isAuthenticated,
  enquiryController.submitEnquiry
);

router.post(
  "/contact/:enquiryId/status",
  isAuthenticated,
  isAdmin,
  enquiryController.updateEnquiryStatus
);

router.post(
  "/contact/:enquiryId/delete",
  isAuthenticated,
  isAdmin,
  enquiryController.deleteEnquiry
);

module.exports = router;
