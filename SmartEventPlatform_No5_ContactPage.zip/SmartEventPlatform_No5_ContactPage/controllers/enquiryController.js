const Enquiry = require("../models/Enquiry");

exports.getContactPage = async (req, res) => {
  try {
    let enquiries = [];

    if (req.session.user && req.session.user.role === "admin") {
      enquiries = await Enquiry.find()
      .sort({ createdAt: -1 });;
    }

    res.render("contact", {
      pageTitle: "Contact / Enquiry Management",
      enquiries,
      successMessage: null,
      errorMessage: null
    });
  } catch (error) {
    console.error(error);

    res.render("contact", {
      pageTitle: "Contact / Enquiry Management",
      enquiries: [],
      successMessage: null,
      errorMessage: "Unable to load contact page."
    });
  }
};

exports.submitEnquiry = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      let enquiries = [];

      if (req.session.user && req.session.user.role === "admin") {
        enquiries = await Enquiry.find().sort({ createdAt: -1 });
      }

      return res.render("contact", {
        pageTitle: "Contact / Enquiry Management",
        enquiries,
        successMessage: null,
        errorMessage: "Please complete all fields."
      });
    }

    const newEnquiry = await Enquiry.create({
      name,
      email,
      subject,
      message
    });

    console.log("Saved enquiry:", newEnquiry);

    let enquiries = [];

    if (req.session.user && req.session.user.role === "admin") {
      enquiries = await Enquiry.find()
      .sort({ createdAt: -1 });
    }

    res.render("contact", {
      pageTitle: "Contact / Enquiry Management",
      enquiries,
      successMessage: "Your enquiry has been submitted successfully.",
      errorMessage: null
    });
  } catch (error) {
    console.error("Submit enquiry error:", error);

    res.render("contact", {
      pageTitle: "Contact / Enquiry Management",
      enquiries: [],
      successMessage: null,
      errorMessage: "Something went wrong. Please try again."
    });
  }
};
exports.updateEnquiryStatus = async (req, res) => {
  try {
    const { enquiryId } = req.params;
    const { status } = req.body;

    const allowedStatuses = ["New", "In Progress", "Resolved"];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).send("Invalid enquiry status.");
    }

    await Enquiry.findByIdAndUpdate(enquiryId, {
      status
    });

    res.redirect("/contact");
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to update enquiry status.");
  }
};

exports.deleteEnquiry = async (req, res) => {
  try {
    const { enquiryId } = req.params;

    await Enquiry.findByIdAndDelete(enquiryId);

    res.redirect("/contact");
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to delete enquiry.");
  }
};
