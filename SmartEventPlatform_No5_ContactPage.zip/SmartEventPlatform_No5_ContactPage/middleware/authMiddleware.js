function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }

  return res.redirect("/auth");
}

function isAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === "admin") {
    return next();
  }

  return res.status(403).send("Access denied. Admins only.");
}

function setUserLocals(req, res, next) {
  res.locals.currentUser = req.session.user || null;
  next();
}

module.exports = {
  isAuthenticated,
  isAdmin,
  setUserLocals
};
