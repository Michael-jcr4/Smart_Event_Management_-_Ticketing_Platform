Project Title and Overview
==========================

Project Title:
Smart Event Management and Ticketing Platform

Overview:
The Smart Event Management and Ticketing Platform is a full-stack web application designed for Advanced Events (Pty) Ltd. The purpose of the system is to help the company manage events, ticket bookings, user enquiries, and administrative tasks more efficiently.

The platform allows users to view available events, submit enquiries, and interact with the system through a secure and user-friendly interface. Administrators are able to manage event-related information and handle user enquiries through role-based access control.

This project focuses on creating a secure, scalable, and professionally structured system using the MVC architecture.


Technologies Used
=================

The following technologies were used in the project:

- Node.js
- Express.js
- EJS
- MongoDB
- Mongoose
- Express-session
- HTML
- CSS
- JavaScript
- GitHub for version control


Team Members and Roles
======================

Lisa Verson (602006)
HomePage/Event Listing Page

Michael-John Robinson (602310)
User Authentication Page

Nokutenda Madziwa (602551)
Event Management Page

Jordan Naidoo (602463)
Contact / Enquiry Management Page

Everyone
Booking & Dashboard Page


Setup Instructions
==================

Follow these steps to run the project on your computer:

1. Extract the project ZIP file.

2. Open the extracted project folder in Visual Studio Code.

3. Open the terminal in Visual Studio Code.

4. Make sure you are inside the project folder.

5. Install all required packages by running:

   npm install

6. Start MongoDB on your computer.

7. Run the project using:

   npm run dev

   If npm run dev does not work, use:

   node app.js

Reflection
==========

This project helped us understand how a real-world full-stack web application is structured and developed. We learned how to apply the MVC architecture by separating the system into models, views, controllers, routes, and middleware.

The project also improved our understanding of server-side development using Node.js and Express.js. We learned how to connect a web application to MongoDB using Mongoose and how to store user-submitted information in a database.

Another important part of the project was implementing role-based access control. This helped us understand how different users, such as administrators and standard users, can have different permissions in a system.

Overall, the project provided valuable practical experience in building a secure and organized event management platform. It also showed the importance of teamwork, testing, documentation, and version control when developing a software system.
