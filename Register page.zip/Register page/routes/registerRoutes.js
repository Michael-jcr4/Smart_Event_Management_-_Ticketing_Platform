const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/user');

const router = express.Router();

// Render the registration page
router.get('/', (req, res) => {
  res.render('register');
});

// Handle registration form submission
router.post('/register', async (req, res) => {
  const { regName, regEmail, regPassword, regConfirmPassword, role } = req.body;
  const errors = [];
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Validate user input
  if (!regName || regName.trim().length < 2) {
    errors.push('Name must be at least 2 characters long');
  }
  if (!regEmail || !emailRegex.test(regEmail)) {
    errors.push('Please enter a valid email address');
  }
  if (!regPassword || regPassword.length < 6) {
    errors.push('Password must be at least 6 characters long');
  }
  if (regPassword !== regConfirmPassword) {
    errors.push('Passwords do not match');
  }
  if (!role) {
    errors.push('Please select a role');
  }

  if (errors.length > 0) {
    return res.render('register', { errors });
  }

  try {
    const existingUser = await User.findOne({ email: regEmail.toLowerCase().trim() });
    if (existingUser) {
      return res.render('register', { errors: ['Email already exists'] });
    }

    const hashedPassword = await bcrypt.hash(regPassword, 10); // hash user password

    const user = new User({
      name: regName.trim(),
      email: regEmail.toLowerCase().trim(),
      password: hashedPassword,
      role
    });

    await user.save(); // save new user into MongoDB

    // store session data after registration
    req.session.regEmail = user.email;
    req.session.regName = user.name;
    req.session.role = user.role;

    res.redirect('/login');
  } catch (error) {
    console.error('Registration error:', error);
    res.render('register', { errors: ['Registration failed. Please try again.'] });
  }
});

// Render the login page
router.get('/login', (req, res) => {
  res.render('login');
});

// Handle login form submission
router.post('/login', async (req, res) => {
  const { logEmail, logPassword } = req.body;

  if (!logEmail || !logPassword) {
    return res.render('login', { error: 'Please enter both email and password' });
  }

  try {
    const user = await User.findOne({ email: logEmail.toLowerCase().trim() });
    if (!user) {
      return res.render('login', { error: 'Invalid email or password' });
    }

    const isValidPassword = await bcrypt.compare(logPassword, user.password);
    if (!isValidPassword) {
      return res.render('login', { error: 'Invalid email or password' });
    }

    req.session.regEmail = user.email;
    req.session.regName = user.name;
    req.session.role = user.role;

    res.redirect('/');
  } catch (error) {
    console.error('Login error:', error);
    res.render('login', { error: 'Login failed. Please try again.' });
  }
});

// Log the user out and destroy the session
router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.log(err);
    }
    res.redirect('/login');
  });
});

router.get('/auth', (req, res) => {
  res.redirect('/login');
});

module.exports = router;
