module.exports = (req, res, next) => {
    res.locals.currentUser = req.session.regEmail ? {
        name: req.session.regName,
        email: req.session.regEmail,
        role: req.session.role
    } : null;
    next();
};