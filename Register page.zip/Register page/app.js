const express = require('express');
const session = require('express-session');
const app = express();
require('dotenv').config(); // load environment variables from .env
const port = process.env.PORT;
const registerMiddleware = require('./middleware/registerMiddleware');
const registerRouter = require('./routes/registerRoutes');
const mongoose = require('mongoose');

app.set('view engine', 'ejs'); // render views using EJS templates

app.use(express.json());

app.use(express.urlencoded({extended:true}));

app.use(session({
    secret: process.env.KEY, // session secret key from .env
    resave: false,
    saveUninitialized: false
}));

// connect to MongoDB using env connection string
mongoose.connect(process.env.MONGO_URI); 

const db = mongoose.connection;

db.on('connected', () => {
    console.log('MongoDB Connected!');
});

db.on('error', () => {
    console.log('Error connecting MongoDB!');
});

db.on('disconnected', () => {
    console.log('MongoDB Disconnected!');
});

// attach user data to response locals for views
app.use(registerMiddleware); 

// serve static files from public folder
app.use(express.static('public')); 

// use registration routes for registration and login
app.use('/', registerRouter); 

app.listen(port, () => {
    console.log("Server running on port: " + port);
});